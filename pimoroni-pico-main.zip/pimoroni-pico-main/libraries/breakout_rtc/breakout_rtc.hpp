#pragma once

#include "../../drivers/rv3028/rv3028.hpp"

namespace pimoroni {

  typedef RV3028 BreakoutRTC;
}
