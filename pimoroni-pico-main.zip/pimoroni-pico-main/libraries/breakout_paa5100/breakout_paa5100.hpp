#pragma once

#include "drivers/pmw3901/pmw3901.hpp"

namespace pimoroni {

  typedef PMW3901 BreakoutPAA5100;
}
