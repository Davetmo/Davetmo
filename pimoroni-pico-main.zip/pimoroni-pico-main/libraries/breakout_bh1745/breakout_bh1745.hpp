#pragma once

#include "drivers/bh1745/bh1745.hpp"

namespace pimoroni {

  typedef BH1745 BreakoutBH1745;
}
